// Menu functionality
const menu = document.querySelector('#mobile-menu');
const menuLinks = document.querySelector('.navbar__menu');

menu.addEventListener('click', function() {
    menu.classList.toggle('is-active');
    menuLinks.classList.toggle('active');
});

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Alert System Functions
function registerEmail() {
    const email = document.getElementById('register-email').value;
    if (!email || !isValidEmail(email)) {
        alert("Please enter a valid email address.");
        return;
    }

    // Send to backend (you'll need to implement this endpoint)
    fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
    })
    .then(response => response.json())
    .then(data => {
        alert("OTP sent to " + email);
        document.getElementById('register-form').style.display = "none";
        document.getElementById('verify-form').style.display = "block";
    })
    .catch(error => {
        alert("Error sending OTP: " + error.message);
    });
}

function verifyOTP() {
    const otp = document.getElementById('verify-otp').value;
    if (!otp || otp.length < 4) {
        alert("Please enter a valid OTP.");
        return;
    }

    // Send to backend (you'll need to implement this endpoint)
    fetch('/api/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ otp })
    })
    .then(response => response.json())
    .then(data => {
        alert("OTP verified successfully!");
        document.getElementById('verify-form').style.display = "none";
        document.getElementById('alert-form').style.display = "block";
    })
    .catch(error => {
        alert("Error verifying OTP: " + error.message);
    });
}

function sendAlert() {
    const name = document.getElementById('missing-name').value;
    const website = document.getElementById('website-name').value;

    if (!name || !website) {
        alert("Please fill in both name and website fields.");
        return;
    }

    fetch('/api/send-alert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, website })
    })
    .then(response => response.json())
    .then(data => {
        if (data.status) {
            alert("Alert sent successfully!");
            // Clear the form
            document.getElementById('missing-name').value = '';
            document.getElementById('website-name').value = '';
        } else {
            alert("Error: " + data.error);
        }
    })
    .catch(error => {
        alert("Error sending alert: " + error.message);
    });
}

// Helper function to validate email
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Service card buttons
document.querySelectorAll('.services__btn button').forEach(button => {
    button.addEventListener('click', function() {
        const service = this.closest('.services__card').querySelector('h2').textContent;
        alert(`You selected the ${service} service. Please register to continue.`);
        document.querySelector('#alert-section').scrollIntoView({ behavior: 'smooth' });
    });
});

// Sign up button functionality
document.querySelectorAll('a[href="#sign-up"]').forEach(button => {
    button.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector('#sign-up').scrollIntoView({ behavior: 'smooth' });
    });
});

// Schedule call button functionality
document.querySelector('#about .main__btn').addEventListener('click', function(e) {
    e.preventDefault();
    alert('Our team will contact you shortly to schedule a call.');
});

// Explore button functionality
document.querySelector('#home .main__btn').addEventListener('click', function(e) {
    e.preventDefault();
    document.querySelector('#services').scrollIntoView({ behavior: 'smooth' });
});