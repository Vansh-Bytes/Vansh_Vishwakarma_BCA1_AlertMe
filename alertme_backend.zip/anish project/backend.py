from flask import Flask, request, jsonify, send_from_directory
import sqlite3
import json
import os
import random
import string

app = Flask(__name__, static_folder='.')

DB_PATH = 'alertme.db'
SETTINGS_PATH = 'settings.json'
OTP_STORAGE = {}  # In-memory OTP storage (replace with database in production)

# Initialize database
def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            website TEXT NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            verified BOOLEAN DEFAULT FALSE
        )
    """)
    conn.commit()
    conn.close()

# Static file routes
@app.route('/')
def serve_index():
    return send_from_directory('.', 'index.html')

@app.route('/styles.css')
def serve_css():
    return send_from_directory('.', 'styles.css')

@app.route('/app.js')
def serve_js():
    return send_from_directory('.', 'app.js')

# API Routes
@app.route('/api/register', methods=['POST'])
def register():
    try:
        data = request.json
        email = data.get('email')
        if not email:
            return jsonify({'error': 'Email is required'}), 400

        # Generate OTP
        otp = ''.join(random.choices(string.digits, k=6))
        OTP_STORAGE[email] = otp

        # Store user in database
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("INSERT OR REPLACE INTO users (email) VALUES (?)", (email,))
        conn.commit()
        conn.close()

        # In production, send OTP via email here
        print(f"OTP for {email}: {otp}")  # For testing purposes

        return jsonify({'status': 'success', 'message': 'OTP sent'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/verify', methods=['POST'])
def verify():
    try:
        data = request.json
        email = data.get('email')
        otp = data.get('otp')

        if not email or not otp:
            return jsonify({'error': 'Email and OTP are required'}), 400

        stored_otp = OTP_STORAGE.get(email)
        if not stored_otp or stored_otp != otp:
            return jsonify({'error': 'Invalid OTP'}), 400

        # Mark user as verified
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET verified = TRUE WHERE email = ?", (email,))
        conn.commit()
        conn.close()

        # Clear OTP after successful verification
        del OTP_STORAGE[email]

        return jsonify({'status': 'success', 'message': 'OTP verified'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/data/alerts', methods=['GET'])
def get_alerts_data():
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM alerts")
        rows = cursor.fetchall()
        col_names = [description[0] for description in cursor.description]
        conn.close()
        return jsonify([dict(zip(col_names, row)) for row in rows])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/settings', methods=['GET'])
def get_settings():
    try:
        if not os.path.exists(SETTINGS_PATH):
            return jsonify({})
        with open(SETTINGS_PATH, 'r') as f:
            settings = json.load(f)
        return jsonify(settings)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/settings', methods=['POST'])
def update_settings():
    try:
        data = request.json
        with open(SETTINGS_PATH, 'w') as f:
            json.dump(data, f, indent=4)
        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/send-alert', methods=['POST'])
def send_alert():
    try:
        data = request.json
        name = data.get('name')
        website = data.get('website')

        if not name or not website:
            return jsonify({'error': 'Name and website are required'}), 400

        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO alerts (name, website) VALUES (?, ?)", (name, website))
        conn.commit()
        conn.close()

        return jsonify({'status': 'Alert added successfully!'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    init_db()  # Initialize database on startup
    app.run(debug=True)